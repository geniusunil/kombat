package com.zeher.kombat.Screens;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.zeher.kombat.Kombat;

/**
 * Created by zucky on 5/30/2015.
 */
public class IntroScreen implements Screen{
    Kombat game;
    long showTime; //time when the screen showed up
    Texture introbg;
    public IntroScreen (Kombat game){
        this.game=game;
    }
    @Override
    public void show() {
        showTime=System.currentTimeMillis();
        introbg=new Texture("introbg.jpg");
    }

    @Override
    public void render(float delta) {
        Gdx.gl.glClearColor(0, 0, 1, 1);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

        game.font.setScale(8);
        game.batch.begin();
        game.batch.draw(introbg,0,0);
        game.font.drawMultiLine(game.batch, "Karna \n    vs \n       Arjuna", 100, 1200);
        game.font.setScale(5);
        game.font.draw(game.batch, "Touch for a bout!", 100, 750);
        game.font.setScale(3);
        game.font.draw(game.batch, "Major Project by :", 350, 500);
        game.font.setScale(2);
        game.font.draw(game.batch,"Abhishek Verma 3132",400,400);
        game.font.draw(game.batch,"Sunil Kumar 3149",400,350);
        game.font.draw(game.batch,"Deepika Kaushal 3166",400,300);
        game.batch.end();
        if(Gdx.input.isTouched() && System.currentTimeMillis()-showTime>500){
            game.setScreen(new InstructionsScreen(game));
            this.dispose();
        }
    }

    @Override
    public void resize(int width, int height) {

    }

    @Override
    public void pause() {

    }

    @Override
    public void resume() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void dispose() {

    }
}
