package com.zeher.kombat;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.input.GestureDetector;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.utils.Array;
import com.zeher.kombat.Screens.GameScreen;

/**
 * Created by code on 3/27/2015.
 * Class representing the home in game
 */
public class MyGestureListener implements GestureDetector.GestureListener {
    Kombat game;
    Arrow arrow;
    public long lastArrowHit; //time of last arrow hit by user
    public MyGestureListener(Kombat game){
        this.game=game;
        this.arrow=game.gs.arrow;
        //game.gs.initMglNewArrow();
    }
    public void isTouched (int x, int y)  {
        /*Gdx.app.log("occurred: ", "touched");
        */
        Gdx.app.log("touched and checked", x * game.xScale + " " + (game.width-game.gs.controls.controlBounds.getWidth()) + " " + y * game.yScale + " " + (game.height - game.gs.controls.controlBounds.getHeight()));

        if(x*game.xScale <= game.gs.controls.controlBounds.getWidth() && y*game.yScale >= game.height-game.gs.controls.controlBounds.getHeight() && game.gs.playerChar.xPosition>=0) {
            game.gs.playerChar.xPosition -= game.gs.playerChar.walkSpeed;
            try {
                game.gs.arrows.get(game.gs.arrows.size - 1).update(0);
            }catch(ArrayIndexOutOfBoundsException e){

            }

        }
        else if(x*game.xScale >= game.width-game.gs.controls.controlBounds.getWidth() && y*game.yScale >= game.height- game.gs.controls.controlBounds.getHeight()  && game.gs.playerChar.xPosition<game.width-game.width/game.gs.playerChar.screenFractionCharWidth) {
            game.gs.playerChar.xPosition += game.gs.playerChar.walkSpeed;
            try {
                game.gs.arrows.get(game.gs.arrows.size - 1).update(0);
            }catch (ArrayIndexOutOfBoundsException e){

            }

        }


    }
    @Override
    public boolean touchDown(float x, float y, int pointer, int button) {   //even if you keep it touched the function is called only once
        Gdx.app.log("occurred: ", "touchDown");
        return false;
    }

    @Override
    public boolean tap(float x, float y, int count, int button) {
        Gdx.app.log("occurred: ", "tap");
        return false;
    }

    @Override
    public boolean longPress(float x, float y) {
        //Gdx.app.log("occurred: ", "longPress");
        return false;
    }

    @Override
    public boolean fling(float velocityX, float velocityY, int button) {
        //Gdx.app.log("occurred: ", "fling");
        return false;
    }

    @Override
    public boolean pan(float x, float y, float deltaX, float deltaY) {
        Gdx.app.log("occurred: ", "pan");
        /*Gdx.app.log("deltaX and deltaY",deltaX+" "+deltaY);*/
        //Gdx.app.log("x and y",x+" "+y);
        //Gdx.app.log("x*game.xScale",x*game.xScale+"");
        if(x*game.xScale > game.gs.controls.controlBounds.getWidth() && x*game.xScale<game.width-game.gs.controls.controlBounds.getWidth()){
            try {
                game.gs.arrows.get(game.gs.arrows.size - 1).update(-(0.5f * deltaX * game.xScale));
            }
            catch (ArrayIndexOutOfBoundsException e){

            }
        }
        return false;
    }

    @Override
    public boolean panStop(float x, float y, int pointer, int button) {
        Gdx.app.log("occurred: ", "panStop");
        if(System.currentTimeMillis()-lastArrowHit>1800) {
            try {
                game.gs.arrows.get(game.gs.arrows.size - 1).fire();
                lastArrowHit=System.currentTimeMillis();
            }
            catch(IndexOutOfBoundsException e){

            }

            //lastArrowHit=System.currentTimeMillis();

            game.gs.initMglNewArrow();
        }



        return false;
    }

    @Override
    public boolean zoom (float originalDistance, float currentDistance){
        Gdx.app.log("occurred: ", "zoom");
        return false;
    }

    @Override
    public boolean pinch (Vector2 initialFirstPointer, Vector2 initialSecondPointer, Vector2 firstPointer, Vector2 secondPointer){
        Gdx.app.log("occurred: ", "pinch");
        return false;
    }
}