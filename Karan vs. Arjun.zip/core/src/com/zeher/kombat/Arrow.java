package com.zeher.kombat;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.zeher.kombat.Screens.GameScreen;

/**
 * Created by code on 4/7/2015.
 * Class representing the home in game
 */
public class Arrow {
    GameScreen gs;
    SpriteBatch batch;
    Texture arrowImg;
    Texture bow;
    float xPosition;
    float yPosition;
    float xOrigin;
    float yOrigin;
    float arrowWidth;
    float arrowHeight;
    float xScale;
    float yScale;
    float rotation;
    float srcX;
    float srcY;
    float srcWidth;
    float srcHeight;
    boolean flipX;
    boolean flipY;
    float arrowWidthFraction=27;
    float dy,dx;

    // following is for the fire()

    float m;
    float c;

    static boolean arrowWithinScreen;
    public Arrow(GameScreen gs){
        this.gs=gs;
        this.batch = gs.batch;
        bow=new Texture("bow.png");
        arrowImg=new Texture("arrow.png");
        xOrigin=0;
        yOrigin=0;
        xScale=yScale=1;
        srcX=0;
        srcY=0;
        srcWidth=185;
        srcHeight=1762;


        flipX=false;
        flipY=false;
        arrowWidth=gs.game.width/arrowWidthFraction;
        arrowHeight=gs.game.height/gs.playerChar.screenFractionCharHeight;
        xPosition=(gs.playerChar.xPosition)+(((float)50/88)*(gs.game.width/gs.playerChar.screenFractionCharWidth));
        yPosition=gs.game.height/gs.playerChar.screenFractionAbove0+((float)125/180*gs.game.height/gs.playerChar.screenFractionCharHeight);

    }
    public void render() {

        for (int i = 0; i < gs.arrows.size; i++) {
            Arrow arrow=gs.arrows.get(i);
            try {
                batch.draw(bow, xPosition - bow.getWidth() / 2, yPosition, 150, 0, 300, 129, 1, 1, gs.arrows.get(gs.arrows.size - 1).rotation, 0, 0, 300, 129, false, false);
            }catch (ArrayIndexOutOfBoundsException e) {
            }
            if(i==gs.arrows.size-1 && System.currentTimeMillis()-gs.game.mgl.lastArrowHit>1800) {
                batch.draw(arrow.arrowImg, arrow.xPosition, arrow.yPosition, arrow.xOrigin, arrow.yOrigin, arrow.arrowWidth, arrow.arrowHeight, arrow.xScale, arrow.yScale, arrow.rotation, 0, 0, 185, 1762, false, false);
                break;
            }
            else if(i<gs.arrows.size-1)
                batch.draw(arrow.arrowImg, arrow.xPosition, arrow.yPosition, arrow.xOrigin, arrow.yOrigin, arrow.arrowWidth, arrow.arrowHeight, arrow.xScale, arrow.yScale, arrow.rotation, 0, 0, 185, 1762, false, false);
            }
    }

    public void update(float angle){
        xPosition=(gs.playerChar.xPosition)+(((float)50/88)*(gs.game.width/gs.playerChar.screenFractionCharWidth));
        yPosition=gs.game.height/gs.playerChar.screenFractionAbove0+((float)125/180*gs.game.height/gs.playerChar.screenFractionCharHeight);

        rotation+=angle;
        if(rotation>60)
            rotation=60;
        else if(rotation<-60){
            rotation=-60;
        }
    }
    public void fire(){    //when the arrow is fired
        final Arrow thisArrow= this;
        arrowWithinScreen=true;
        m=(float)Math.tan(Math.toRadians(this.rotation+90));
        c=this.yPosition-(m*this.xPosition);
        /*Gdx.app.log("curx and cur y and rot: ",curX+" "+curY+" "+curRot);
        Gdx.app.log("m :",""+m);*/
        thisArrow.dy=(float)Math.abs(thisArrow.arrowHeight * Math.cos(Math.toRadians(thisArrow.rotation)));
        thisArrow.dx=dy/m;
        Thread thread = new Thread(new Runnable() {

            @Override
            public void run() {

                try {

                    while(true) {
                        thisArrow.yPosition++;
                        thisArrow.xPosition=(thisArrow.yPosition-c)/m;
                        Thread.sleep(5);
                        if(arrowHitBot(thisArrow)){
                            thisArrow.dispose();
                            try {
                                gs.arrows.removeIndex(0);
                            }catch (IndexOutOfBoundsException e){

                            }
                            gs.bot.lives--;
                            //Gdx.app.log("arrow remove : ","yes");
                            break;
                        }
                        else if(thisArrow.xPosition<0 || thisArrow.xPosition>720 || thisArrow.yPosition>1280 || thisArrow.yPosition<0){
                            thisArrow.dispose();
                            try {
                                gs.arrows.removeIndex(0);
                            }catch(IndexOutOfBoundsException e){
                            }
                            //Gdx.app.log("arrow remove : ","yes");

                            break;
                        }
                    }



                } catch (InterruptedException e) {
                    e.printStackTrace();
                }


            }
        });
        thread.start();
    }
    public boolean arrowHitBot(Arrow arrow){
        boolean hit = false;
        //Gdx.app.log("height reduced : and dx",arrow.dy+" "+arrow.dx);
        if(arrow.yPosition+dy> gs.game.height / gs.bot.screenFractionAbove0 && arrow.xPosition +dx >= gs.bot.xPosition && arrow.xPosition+dx <= (gs.bot.xPosition + gs.bot.character.getWidth())) {
            hit = true;
        }
        //Gdx.app.log("arrow yPosition :",arrow.yPosition+" bot yPosition :"+gs.game.height / gs.bot.screenFractionAbove0+" arrow xPosition "+arrow.xPosition+" bot xposition"+gs.bot.xPosition);
        return hit;
    }
    public void dispose(){
        //arrowImg.dispose();   //causing black texture, fix this later
    }
}
