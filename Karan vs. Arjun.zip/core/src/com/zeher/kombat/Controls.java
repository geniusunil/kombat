package com.zeher.kombat;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Rectangle;
import com.zeher.kombat.Screens.GameScreen;

public class Controls {
    GameScreen gs;
    SpriteBatch batch;
    TextureRegion dpad;
    TextureRegion left;
    TextureRegion right;
    TextureRegion jump;
    TextureRegion cubeControl;
    TextureRegion cubeFollow;
    Rectangle controlBounds;
    int leftRightWidth=80;
    int leftRightHeight=80;

    public Controls (GameScreen gs) {
        this.gs = gs;
        batch=gs.batch;
        controlBounds=new Rectangle();
        controlBounds.setSize(leftRightWidth,leftRightHeight);
        loadAssets();
    }

    private void loadAssets () {
        Texture texture = new Texture(Gdx.files.internal("controls.png"));
        TextureRegion[] buttons = TextureRegion.split(texture, 64, 64)[0];

        left = buttons[0];
        right = buttons[1];
        jump = buttons[2];
        cubeControl = buttons[3];
        cubeFollow = TextureRegion.split(texture, 64, 64)[1][2];
        dpad = new TextureRegion(texture, 0, 64, 128, 128);
    }

    public void render () {
        batch.draw(left, 0, 0,controlBounds.getWidth(),controlBounds.getHeight());
        batch.draw(right, gs.game.width-controlBounds.getWidth(), 0,controlBounds.getWidth(),controlBounds.getHeight());
        batch.draw(cubeControl, 320,0,80,80);
    }

    public void dispose () {

        left.getTexture().dispose();
        right.getTexture().dispose();
        jump.getTexture().dispose();
        cubeControl.getTexture().dispose();
        cubeFollow.getTexture().dispose();
        dpad.getTexture().dispose();
    }
}
